IdeaFarm (tm) Knowledge Tree


An IdeaFarm (tm) Knowledge Tree is a multimedia hypertext document.
Knowledge trees are distributed as "html files" accompanied by audio
and video files, and are viewed by opening the file named "index.html".
When this is done, your web browser will appear.

These files comprise one "shipping volume" of a possibly multivolume set.
Copy this entire shipping volume, and all others in the set, into a new
folder.  The order in which you copy multiple volumes of a set does not matter.
Open that folder, and then open the file "index.html".

For a periodical, each new issue is shipped as a volume or set of volumes.
Copy the volumes of the new issue into the folder that contains prior issues.

If you are a new subscriber, ask the publisher whether a prior issues are
available.
