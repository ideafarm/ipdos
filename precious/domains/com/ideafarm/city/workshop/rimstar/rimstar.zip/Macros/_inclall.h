#define INCL_EVENT
#define INCL_IO
#define INCL_MENU
#define INCL_MOUSE
#include "macro.h"
